﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registration
{
    class Conection
    {
        public SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\CRUD\Registration\Registration\CRUD.mdf;Integrated Security=True");
        public SqlCommand cmd = new SqlCommand();
        public DataTable dt = new DataTable();
        
    }
}


