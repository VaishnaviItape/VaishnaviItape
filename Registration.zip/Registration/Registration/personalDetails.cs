﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class personalDetails : Form
    {
        Conection con = new Conection();
        public void clear()
        {
            txtName.Text = " ";
            txtPhoneNo.Text = " ";
            txtAddress.Text = " ";
            txtRollno.Text = " ";
        }
        public personalDetails()
        {
            InitializeComponent();
        }
        public void showfield()
        {
            try
            {
                con.cn.Open();
                con.dt.Clear();
                con.dt.Rows.Clear();
                con.cmd.CommandText = "select * from PersonalDetails";
                con.cmd.Connection = con.cn;
                con.dt.Load(con.cmd.ExecuteReader());
                foreach (DataColumn dc in con.dt.Columns)
                {
                    cbSelectColumn.Items.Add(dc.ColumnName);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }
        
        public void showgrid()
        {
            try
            {
                con.cn.Close();
                con.dt.Clear();

                con.cn.Open();
                con.cmd.CommandText = "Select * from PersonalDetails";
                con.cmd.Connection = con.cn;

                con.dt.Load(con.cmd.ExecuteReader());
                dgvPersonalDetails.DataSource = con.dt;
                con.cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            clear();
            try
            {
                con.cn.Open();
                con.cmd.CommandText = " select count(Id)from PersonalDetails";
                con.cmd.Connection = con.cn;
                int n = Convert.ToInt32(con.cmd.ExecuteScalar());
                n++;
                string id = n.ToString();
                con.cn.Close();

                txtRollno.Text = id.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
            btnSave.Enabled = true;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtName.Text == " ")
                {
                    MessageBox.Show("Please Enter the name");

                }
                if (txtPhoneNo.Text == " ")
                {
                    MessageBox.Show("Plesae Enter Phone No");
                }
                if (txtAddress.Text == " ")
                {
                    MessageBox.Show("Plesae Enter Address");
                }
                con.cn.Close();
                con.cn.Open();
                con.cmd.CommandText = "insert into PersonalDetails values(" + txtRollno.Text + ",'" + txtName.Text + "'," + txtPhoneNo.Text + ",'" + txtAddress.Text + "',@p1)";
                con.cmd.Connection = con.cn;
                if (rbOther.Checked == true)
                {
                    con.cmd.Parameters.AddWithValue("@p1", rbOther.Text);
                }
                else if (rbFemale.Checked == true)
                {
                    con.cmd.Parameters.AddWithValue("@p1", rbFemale.Text);
                }
                else
                {
                    con.cmd.Parameters.AddWithValue("@p1", rbMale.Text);
                }
                con.cmd.ExecuteNonQuery();
               // clear();
                showgrid();



                MessageBox.Show("Personal Information Saved Sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "Update PersonalDetails set  Name='" + txtName.Text + "',PhoneNo=" + txtPhoneNo.Text + ",Address='" + txtAddress.Text + "' where Id=" + txtRollno.Text + "";

                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
               

                MessageBox.Show("Personal Information Updated Sucessfully");
                showgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void personalDetails_Load(object sender, EventArgs e)
        {
            showgrid();
            showfield();
            txtName.Focus();
        }

        private void cbSelectOperator_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string str;
            try
            {
                con.cn.Close();
                con.cn.Open();

                if (cbSelectColumn.Text == "")
                    MessageBox.Show("please Select teh column", "validation", MessageBoxButtons.OK);
                else if (cbSelectOperator.Text == "")
                    MessageBox.Show("Please Select operator", "Validation", MessageBoxButtons.OK);
                else if (txtEnterData.Text == "")
                    MessageBox.Show("Please Enter value", "Validation", MessageBoxButtons.OK);
                else
                {
                    if (cbSelectOperator.Text == "LIKE" || cbSelectOperator.Text == "NOT LIKE")
                        str = String.Format("{0} where {1} {2} '{3}%'", "Select * from PersonalDetails", cbSelectColumn.Text, cbSelectOperator.Text, txtEnterData.Text);
                    else if (cbSelectOperator.Text == "MASTERDATA")
                        str = String.Format("{0} ", "Select * from PersonalDetails", cbSelectColumn.Text, cbSelectOperator.Text, txtEnterData.Text);
                    else
                        str = String.Format("{0} where {1}{2}'{3}'", "Select * from PersonalDetails", cbSelectColumn.Text, cbSelectOperator.Text, txtEnterData.Text);

                    con.dt.Clear();
                    con.dt.Rows.Clear();
                    con.cmd.CommandText = str;
                    con.cmd.Connection = con.cn;
                    con.dt.Load(con.cmd.ExecuteReader());
                    dgvPersonalDetails.DataSource = con.dt;
                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void dgvPersonalDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtRollno.Text = dgvPersonalDetails.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtName.Text = dgvPersonalDetails.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtPhoneNo.Text = dgvPersonalDetails.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtAddress.Text = dgvPersonalDetails.Rows[e.RowIndex].Cells[3].Value.ToString();
            string ms = dgvPersonalDetails.Rows[e.RowIndex].Cells[4].Value.ToString();
            if (ms == "Male")
                rbMale.Checked = true;
            else if (ms == "Female")
                rbFemale.Checked = true;
            else
                rbOther.Checked = true;

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "delete from PersonalDetails where Id=" + txtRollno.Text + " ";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
              
                con.cn.Close();
                showgrid();
                MessageBox.Show("Personal Information Deleted Sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }
    }
}
