﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy
{
    public partial class FeeForm : Form
    {
        Connection con = new Connection();
        public FeeForm()
        {
            InitializeComponent();
        }
        public void showgrid()
        {
            try
            {
                con.cn.Close();
                con.dt1.Clear();

                con.cn.Open();
                con.cmd.CommandText = "Select * from FeeInfo";
                con.cmd.Connection = con.cn;

                con.dt1.Load(con.cmd.ExecuteReader());
                dgvFee.DataSource = con.dt1;
                con.cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void label5_Click(object sender, EventArgs e)
        {

        }
        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = " select count(FeeId)from FeeInfo";
                con.cmd.Connection = con.cn;
                int n = Convert.ToInt32(con.cmd.ExecuteScalar());
                n++;
                string id = n.ToString();
                con.cn.Close();

                txtFeeId.Text = id.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "delete from FeeInfo where FeeId=" + txtFeeId.Text + " ";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                Clear();
                con.cn.Close();
                showgrid();
                MessageBox.Show("Fee Information Deleted Sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "Update FeeInfo set  SName='" + cbstudentName.Text + "',Batch='" + cbBatch.Text + "',fee=" + cbFee.Text + ",Discount=" + txtDiscount.Text + ",FeePaid=" + txtFeePaid.Text + ",DOP='" + dtpDOP.Text + "',nextDueDate='"+dtpNDD.Text+"',CourseName='"+cbCourseName.Text+"' where FeeId=" + txtFeeId.Text + "";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                //Clear();
                MessageBox.Show("Fee Information Updated Sucessfully");
                showgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
            Clear();
        }

        private void FeeForm_Load(object sender, EventArgs e)
        {   
            //CourseName();
           
            showgrid();
            Student();
            
        }

        private void cbBatch_SelectedIndexChanged(object sender, EventArgs e)
        {

        } 
        public void Clear()
        {
            txtDiscount.Text=" ";
            txtFeeId.Text = " ";
            cbCourseName.Text = " ";
            cbstudentName.Text = " ";
            txtFeePaid.Text = " ";
            txtDiscount.Text = " ";
            cbBatch.Text = " ";
        }
         public void Student()
        {
            try
            {
                con.cn.Close();
                con.dt5.Clear();
                con.cn.Open();
                con.cmd.CommandText = " Select * from SpeakHub";
                //Where Batch=" + cbBatch.SelectedValue + " ";
                con.cmd.Connection = con.cn;
                con.dt5.Load(con.cmd.ExecuteReader());
                cbstudentName.DataSource = con.dt5;
                cbstudentName.DisplayMember = "SName";
                cbstudentName.ValueMember = "SName";


                con.cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
           
        }
        private void cbBatch_SelectionChangeCommitted(object sender, EventArgs e)
        {
           
        }
       
        

        private void cbstudentName_SelectionChangeCommitted(object sender, EventArgs e)
        {
           
        }

        private void cbCourseName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try {
                con.cn.Close();
                con.cmd.Parameters.Clear();
                con.cn.Open();
                con.cmd.CommandText = "insert into FeeInfo values(" + txtFeeId.Text + ",'" + cbstudentName.Text + "','" + cbBatch.Text + "'," + cbFee.Text + "," + txtDiscount.Text + "," + txtFeePaid.Text + ",'" + dtpDOP.Text + "','" + dtpNDD.Text + "','" + cbCourseName.Text + "')";
                MessageBox.Show("Fee Information svaed Sucessfully");
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                Clear();
                showgrid();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


            
        }

        private void dgvRegistration_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtFeeId.Text = dgvFee.Rows[e.RowIndex].Cells[0].Value.ToString();
            cbstudentName.Text = dgvFee.Rows[e.RowIndex].Cells[1].Value.ToString();
            cbBatch.Text = dgvFee.Rows[e.RowIndex].Cells[2].Value.ToString();
            cbFee.Text = dgvFee.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtDiscount.Text = dgvFee.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtFeePaid.Text = dgvFee.Rows[e.RowIndex].Cells[5].Value.ToString();
            dtpDOP.Text = dgvFee.Rows[e.RowIndex].Cells[6].Value.ToString();
            dtpNDD.Text = dgvFee.Rows[e.RowIndex].Cells[7].Value.ToString();
            cbCourseName.Text = dgvFee.Rows[e.RowIndex].Cells[8].Value.ToString();


            
        }
    }
}
