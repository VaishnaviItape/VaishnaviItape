﻿namespace SpeakHubAccademy
{
    partial class MDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDI));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MASTERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACHATGATREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDMINISTARTIONFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TRANSCTIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fEEFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDMINISTRATIONREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGISTRATIONREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uTILITYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cALENDERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nOTEPADToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cALCULATORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hELPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1370, 772);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 707);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1370, 65);
            this.panel3.TabIndex = 82;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Maroon;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel5.Controls.Add(this.menuStrip1);
            this.panel5.Location = new System.Drawing.Point(2, 100);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1370, 41);
            this.panel5.TabIndex = 80;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Maroon;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MASTERToolStripMenuItem,
            this.TRANSCTIONToolStripMenuItem,
            this.rEPORTToolStripMenuItem,
            this.uTILITYToolStripMenuItem,
            this.hELPToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(349, 3);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(20, 5, 20, 5);
            this.menuStrip1.Size = new System.Drawing.Size(694, 38);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MASTERToolStripMenuItem
            // 
            this.MASTERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bACHATGATREPORTToolStripMenuItem,
            this.aDMINISTARTIONFORMToolStripMenuItem});
            this.MASTERToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MASTERToolStripMenuItem.Name = "MASTERToolStripMenuItem";
            this.MASTERToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.MASTERToolStripMenuItem.Size = new System.Drawing.Size(133, 28);
            this.MASTERToolStripMenuItem.Text = "MASTER";
            // 
            // bACHATGATREPORTToolStripMenuItem
            // 
            this.bACHATGATREPORTToolStripMenuItem.Name = "bACHATGATREPORTToolStripMenuItem";
            this.bACHATGATREPORTToolStripMenuItem.Size = new System.Drawing.Size(317, 28);
            this.bACHATGATREPORTToolStripMenuItem.Text = "REGISTRATION FORM";
            this.bACHATGATREPORTToolStripMenuItem.Click += new System.EventHandler(this.bACHATGATREPORTToolStripMenuItem_Click);
            // 
            // aDMINISTARTIONFORMToolStripMenuItem
            // 
            this.aDMINISTARTIONFORMToolStripMenuItem.Name = "aDMINISTARTIONFORMToolStripMenuItem";
            this.aDMINISTARTIONFORMToolStripMenuItem.Size = new System.Drawing.Size(317, 28);
            this.aDMINISTARTIONFORMToolStripMenuItem.Text = "ADMINISTARTION FORM";
            this.aDMINISTARTIONFORMToolStripMenuItem.Click += new System.EventHandler(this.aDMINISTARTIONFORMToolStripMenuItem_Click);
            // 
            // TRANSCTIONToolStripMenuItem
            // 
            this.TRANSCTIONToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fEEFORMToolStripMenuItem});
            this.TRANSCTIONToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.TRANSCTIONToolStripMenuItem.Name = "TRANSCTIONToolStripMenuItem";
            this.TRANSCTIONToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.TRANSCTIONToolStripMenuItem.Size = new System.Drawing.Size(195, 28);
            this.TRANSCTIONToolStripMenuItem.Text = "TRANSACTION";
            // 
            // fEEFORMToolStripMenuItem
            // 
            this.fEEFORMToolStripMenuItem.Name = "fEEFORMToolStripMenuItem";
            this.fEEFORMToolStripMenuItem.Size = new System.Drawing.Size(175, 28);
            this.fEEFORMToolStripMenuItem.Text = "FEE FORM";
            this.fEEFORMToolStripMenuItem.Click += new System.EventHandler(this.fEEFORMToolStripMenuItem_Click);
            // 
            // rEPORTToolStripMenuItem
            // 
            this.rEPORTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDMINISTRATIONREPORTToolStripMenuItem,
            this.rEGISTRATIONREPORTToolStripMenuItem});
            this.rEPORTToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rEPORTToolStripMenuItem.Name = "rEPORTToolStripMenuItem";
            this.rEPORTToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rEPORTToolStripMenuItem.Size = new System.Drawing.Size(130, 28);
            this.rEPORTToolStripMenuItem.Text = "REPORT";
            // 
            // aDMINISTRATIONREPORTToolStripMenuItem
            // 
            this.aDMINISTRATIONREPORTToolStripMenuItem.Name = "aDMINISTRATIONREPORTToolStripMenuItem";
            this.aDMINISTRATIONREPORTToolStripMenuItem.Size = new System.Drawing.Size(303, 28);
            this.aDMINISTRATIONREPORTToolStripMenuItem.Text = "MASTER REPORT";
            this.aDMINISTRATIONREPORTToolStripMenuItem.Click += new System.EventHandler(this.aDMINISTRATIONREPORTToolStripMenuItem_Click);
            // 
            // rEGISTRATIONREPORTToolStripMenuItem
            // 
            this.rEGISTRATIONREPORTToolStripMenuItem.Name = "rEGISTRATIONREPORTToolStripMenuItem";
            this.rEGISTRATIONREPORTToolStripMenuItem.Size = new System.Drawing.Size(303, 28);
            this.rEGISTRATIONREPORTToolStripMenuItem.Text = "REGISTRATION REPORT";
            this.rEGISTRATIONREPORTToolStripMenuItem.Click += new System.EventHandler(this.rEGISTRATIONREPORTToolStripMenuItem_Click);
            // 
            // uTILITYToolStripMenuItem
            // 
            this.uTILITYToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cALENDERToolStripMenuItem,
            this.nOTEPADToolStripMenuItem,
            this.cALCULATORToolStripMenuItem,
            this.adminFormToolStripMenuItem});
            this.uTILITYToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.uTILITYToolStripMenuItem.Name = "uTILITYToolStripMenuItem";
            this.uTILITYToolStripMenuItem.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.uTILITYToolStripMenuItem.Size = new System.Drawing.Size(124, 28);
            this.uTILITYToolStripMenuItem.Text = "UTILITY";
            // 
            // cALENDERToolStripMenuItem
            // 
            this.cALENDERToolStripMenuItem.Name = "cALENDERToolStripMenuItem";
            this.cALENDERToolStripMenuItem.Size = new System.Drawing.Size(213, 28);
            this.cALENDERToolStripMenuItem.Text = "CALENDER";
            this.cALENDERToolStripMenuItem.Click += new System.EventHandler(this.cALENDERToolStripMenuItem_Click);
            // 
            // nOTEPADToolStripMenuItem
            // 
            this.nOTEPADToolStripMenuItem.Name = "nOTEPADToolStripMenuItem";
            this.nOTEPADToolStripMenuItem.Size = new System.Drawing.Size(213, 28);
            this.nOTEPADToolStripMenuItem.Text = "NOTEPAD";
            this.nOTEPADToolStripMenuItem.Click += new System.EventHandler(this.nOTEPADToolStripMenuItem_Click);
            // 
            // cALCULATORToolStripMenuItem
            // 
            this.cALCULATORToolStripMenuItem.Name = "cALCULATORToolStripMenuItem";
            this.cALCULATORToolStripMenuItem.Size = new System.Drawing.Size(213, 28);
            this.cALCULATORToolStripMenuItem.Text = "CALCULATOR";
            this.cALCULATORToolStripMenuItem.Click += new System.EventHandler(this.cALCULATORToolStripMenuItem_Click);
            // 
            // adminFormToolStripMenuItem
            // 
            this.adminFormToolStripMenuItem.Name = "adminFormToolStripMenuItem";
            this.adminFormToolStripMenuItem.Size = new System.Drawing.Size(213, 28);
            this.adminFormToolStripMenuItem.Text = "ADMIN FORM";
            this.adminFormToolStripMenuItem.Click += new System.EventHandler(this.adminFormToolStripMenuItem_Click);
            // 
            // hELPToolStripMenuItem
            // 
            this.hELPToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.hELPToolStripMenuItem.Name = "hELPToolStripMenuItem";
            this.hELPToolStripMenuItem.Size = new System.Drawing.Size(70, 28);
            this.hELPToolStripMenuItem.Text = "HELP";
            this.hELPToolStripMenuItem.Click += new System.EventHandler(this.hELPToolStripMenuItem_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.SystemColors.Info;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1370, 100);
            this.panel2.TabIndex = 79;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(621, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(528, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(374, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "SPEAK HUB ACADEMY";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(496, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(296, 55);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SpeakHubAccademy.Properties.Resources.IMG_20240512_WA0004;
            this.pictureBox4.Location = new System.Drawing.Point(11, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(56, 38);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SpeakHubAccademy.Properties.Resources.istockphoto_1370051659_612x612;
            this.pictureBox3.Location = new System.Drawing.Point(190, 257);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(957, 444);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 81;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1318, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(39, 32);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(438, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(86, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(214, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Speak Hub Academy";
            // 
            // MDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 772);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Name = "MDI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MASTERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bACHATGATREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TRANSCTIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uTILITYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cALENDERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nOTEPADToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cALCULATORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hELPToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem aDMINISTARTIONFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fEEFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDMINISTRATIONREPORTToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStripMenuItem rEGISTRATIONREPORTToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label2;
    }
}