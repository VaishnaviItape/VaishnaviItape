﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy
{
    public partial class AdminForm : Form
    {
        Connection con = new Connection();
        public void clear()
        {
            txtUserName.Text = " ";
            txtNewPassword.Text = " ";
            txtConfirmPassword.Text = " ";

        }
        public void showgrid()
        {
            try
            {
                con.cn.Close();
                con.dt.Clear();
                con.cn.Open();
                con.cmd.CommandText = " select * from Login";
                con.cmd.Connection = con.cn;
                con.dt.Load(con.cmd.ExecuteReader());
                dgvManageAdmin.DataSource = con.dt;
                con.cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
        public AdminForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                if (txtNewPassword.Text == txtConfirmPassword.Text)
                {
                    con.cmd.CommandText = "insert into Login Values('" + txtUserName.Text + "','" + txtNewPassword.Text + "')";
                    con.cmd.ExecuteNonQuery();
                    clear();
                    showgrid();
                    con.cn.Close();
                    MessageBox.Show("Data saved sucessfully");
                }
                else
                    MessageBox.Show("Please check the password");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void btnMagageUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                if (txtNewPassword.Text == txtConfirmPassword.Text)
                {
                    con.cmd.CommandText = "update Login set Password= '" + txtNewPassword.Text + "'  where username='" + txtUserName.Text + "' ";
                    con.cmd.Connection = con.cn;
                    con.cmd.ExecuteNonQuery();
                    con.cn.Close();
                    clear();
                    showgrid();
                    MessageBox.Show("Data updated sucessfully");
                }
                else
                    MessageBox.Show(" Please check your password....");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void btnManageDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = " delete from Login where username='" + txtUserName.Text + "' ";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                con.cn.Close();
                clear();
                showgrid();
                MessageBox.Show("Data Deleted sucessfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void dgvManageAdmin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtUserName.Text = dgvManageAdmin.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtOldPasword.Text = dgvManageAdmin.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        } 

        private void AdminForm_Load(object sender, EventArgs e)
        {
            showgrid();
        }
    }
}
