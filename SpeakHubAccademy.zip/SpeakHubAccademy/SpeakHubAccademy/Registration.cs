﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy
{
    public partial class Registration : Form
    {
        Connection con = new Connection();
        public Registration()
        {
            InitializeComponent();
        }
        public void Clear()
        {
            txtRollNo.Text = " ";
            txtSname.Text = " ";
            txtAddress.Text = " ";
            cbqualification.Text = " ";
            cbCN.Text = " ";
            cbteachername.Text = " ";
            cbFee.Text = " ";
            cbBatch.Text = " ";
            txtMobileno.Text = " ";
            rbOffline.Text = " ";
            rbOnline.Text = " ";
            txtPhoto.Text = " ";

        }
        public void showgrid()
        {
            try
            {
                con.cn.Close();
                con.dt.Clear();

                con.cn.Open();
                con.cmd.CommandText = "Select * from SpeakHub";
                con.cmd.Connection = con.cn;

                con.dt.Load(con.cmd.ExecuteReader());
                dgvRegistration.DataSource = con.dt;
                con.cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = " select count(Id)from SpeakHub";
                con.cmd.Connection = con.cn;
                int n = Convert.ToInt32(con.cmd.ExecuteScalar());
                n++;
                string id = n.ToString();
                con.cn.Close();

                txtRollNo.Text = id.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }
        

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            con.cn.Close();
            con.cmd.Parameters.Clear();
            con.cn.Open();
            con.cmd.CommandText = "insert into SpeakHub values(" + txtRollNo.Text + ",'" + txtSname.Text + "','" + txtAddress.Text + "','" + cbqualification.Text + "','" + cbCN.Text + "','" + cbteachername.Text + "','" + cbFee.Text + "','" + dtpDOB.Text + "','" + dtpJD.Text + "','" + cbBatch.Text + "',@p1,'" + txtMobileno.Text + "','"+txtPhoto.Text+"') ";
            if (rbOnline.Checked == true)
            {
                con.cmd.Parameters.AddWithValue("@p1", rbOnline.Text);
            }
            else
            {
                con.cmd.Parameters.AddWithValue("@p1", rbOffline.Text);
            }
            con.cmd.Connection = con.cn;
            con.cmd.ExecuteNonQuery();
            Clear();
            showgrid();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "Update SpeakHub set  SName='" + txtSname.Text + "',Address='" + txtAddress.Text + "',Qualification='" + cbqualification.Text + "',CourseName='" + cbCN.Text + "',TeacherName='" + cbteachername.Text + "',Fee=" + cbFee.Text + ",DOB='" + dtpDOB.Text + "',DOJ='" + dtpJD.Text + "',Batch='" + cbBatch.Text + "',MNo="+txtMobileno.Text+",Sphoto='"+txtPhoto.Text+"' where Id=" + txtRollNo.Text + "";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                //Clear();
                MessageBox.Show("Student Information Updated Sucessfully");
                showgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
            Clear();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "images only|*.jpeg;*.jpg;*.png;*.gif;";
                DialogResult result = dialog.ShowDialog();

                pbSP.Image = Image.FromFile(dialog.FileName);
                txtPhoto.Text = dialog.FileName;

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "delete from SpeakHub where Id=" + txtRollNo.Text + " ";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                Clear();
                con.cn.Close();
                showgrid();
                MessageBox.Show("Registration Information Deleted Sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void dgvRegistration_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtRollNo.Text = dgvRegistration.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtSname.Text = dgvRegistration.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtAddress.Text = dgvRegistration.Rows[e.RowIndex].Cells[2].Value.ToString();
            cbqualification.Text = dgvRegistration.Rows[e.RowIndex].Cells[3].Value.ToString();
            cbCN.Text = dgvRegistration.Rows[e.RowIndex].Cells[4].Value.ToString();
            cbteachername.Text = dgvRegistration.Rows[e.RowIndex].Cells[5].Value.ToString();
            cbFee.Text = dgvRegistration.Rows[e.RowIndex].Cells[6].Value.ToString();
            dtpDOB.Text = dgvRegistration.Rows[e.RowIndex].Cells[7].Value.ToString();
            dtpJD.Text = dgvRegistration.Rows[e.RowIndex].Cells[8].Value.ToString();
            cbBatch.Text = dgvRegistration.Rows[e.RowIndex].Cells[9].Value.ToString();
            string ms = dgvRegistration.Rows[e.RowIndex].Cells[10].Value.ToString();
            if (ms == "Offline")
                rbOffline.Checked = true;
            else 
                rbOnline.Checked = true;
            txtMobileno.Text = dgvRegistration.Rows[e.RowIndex].Cells[11].Value.ToString();
            txtPhoto.Text = dgvRegistration.Rows[e.RowIndex].Cells[12].Value.ToString();
            pbSP.ImageLocation = txtPhoto.Text;

        }

        private void Registration_Load(object sender, EventArgs e)
        {
            showgrid();
        }

        private void dgvRegistration_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
