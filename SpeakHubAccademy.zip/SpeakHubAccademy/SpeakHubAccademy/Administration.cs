﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy
{
    public partial class Administration : Form
    {
        Connection con = new Connection();
        public Administration()
        {
            InitializeComponent();
        }
        public void showgrid()
        {
            try
            {
                con.cn.Close();
                con.dt.Clear();

                con.cn.Open();
                con.cmd.CommandText = "Select * from Adminstration";
                con.cmd.Connection = con.cn;

                con.dt.Load(con.cmd.ExecuteReader());
                dgvRegistration.DataSource = con.dt;
                con.cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "images only|*.jpeg;*.jpg;*.png;*.gif;";
                DialogResult result = dialog.ShowDialog();

                pbteacherPhoto.Image = Image.FromFile(dialog.FileName);
                txtPhoto.Text = dialog.FileName;

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.ToString());
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void Clear()
        {
            txtAI.Text = " ";
            txtTeacherName.Text = " ";
            cbqualification.Text = " ";
            txtNoOfStudent.Text = " ";
            txtPhoto.Text = " ";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = " select count(AdId)from Adminstration";
                con.cmd.Connection = con.cn;
                int n = Convert.ToInt32(con.cmd.ExecuteScalar());
                n++;
                string id = n.ToString();
                con.cn.Close();

                txtAI.Text = id.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Close();
                con.cmd.Parameters.Clear();
                con.cn.Open();
                con.cmd.CommandText = "insert into Adminstration values(" + txtAI.Text + ",'" + txtTeacherName.Text + "','" + cbqualification.Text + "','" + dtpDateOfBirth.Text + "','" + txtNoOfStudent.Text + "','" + dtpDOJ.Text + "','" + txtPhoto.Text + "')";
                MessageBox.Show("Administartion Information Svaed Sucessfully");
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                Clear();
                showgrid();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "delete from Adminstration where AdId=" + txtAI.Text + " ";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                Clear();
                con.cn.Close();
                showgrid();
                MessageBox.Show("Administration Information Deleted Sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Open();
                con.cmd.CommandText = "Update Adminstration set  TeacherName='" + txtTeacherName.Text + "',Qualification='" + cbqualification.Text + "',DOB='" + dtpDateOfBirth.Text + "',NoOfStudent='" + txtNoOfStudent.Text + "',JoiningDate='" + dtpDOJ.Text + "',TeacherPhoto='" + txtPhoto.Text + "' where AdId=" + txtAI.Text + "";
                con.cmd.Connection = con.cn;
                con.cmd.ExecuteNonQuery();
                //Clear();
                MessageBox.Show("Administration Information Updated Sucessfully");
                showgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.cn.Close();
            }
            Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Administration_Load(object sender, EventArgs e)
        {
            showgrid();
        }

        private void dgvRegistration_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtAI.Text = dgvRegistration.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTeacherName.Text = dgvRegistration.Rows[e.RowIndex].Cells[1].Value.ToString();
            cbqualification.Text = dgvRegistration.Rows[e.RowIndex].Cells[2].Value.ToString();
            dtpDateOfBirth.Text = dgvRegistration.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtNoOfStudent.Text = dgvRegistration.Rows[e.RowIndex].Cells[4].Value.ToString();
            dtpDOJ.Text = dgvRegistration.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtPhoto.Text = dgvRegistration.Rows[e.RowIndex].Cells[6].Value.ToString();
            pbteacherPhoto.ImageLocation = txtPhoto.Text;
            //dtpDateOfBirth.Text = dgvRegistration.Rows[e.RowIndex].Cells[3].Value.ToString();
        }
    }
}
