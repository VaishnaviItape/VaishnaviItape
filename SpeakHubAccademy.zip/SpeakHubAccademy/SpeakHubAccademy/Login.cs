﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy
{
    public partial class Login : Form
    {
        string strUsername, strPassword;
        Connection con = new Connection();
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtUserName.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                txtUserName.Focus();
                con.cn.Close();
                con.cn.Open();
                con.cmd.CommandText = "Select * from Login where username='" + txtUserName.Text + "' ";
                con.cmd.Connection = con.cn;
                con.dr = con.cmd.ExecuteReader();
                if (con.dr.HasRows)
                {
                    while (con.dr.Read())
                    {
                        strUsername = con.dr.GetString(0);
                        strPassword = con.dr.GetString(1);
                    }
                }
                con.cn.Close();
                if (strUsername == txtUserName.Text && strPassword == txtPassword.Text)
                {
                    MessageBox.Show("Login Sucessfully");
                    this.Hide();
                    Login md = new Login();
                    md.Show();

                    MDI m = new MDI();
                    m.Show();
                }
                else
                {
                    MessageBox.Show("Confirm your username or password ", "Admin Login", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
    }
}
