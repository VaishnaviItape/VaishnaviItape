﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy
{
    public partial class MDI : Form
    {
        public MDI()
        {
            InitializeComponent();
        }
       
private void bACHATGATREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Registration rg = new Registration();
            rg.Show();
        }

        private void aDMINISTARTIONFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Administration ad = new Administration();
            ad.Show();
        }

        private void fEEFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeeForm fe = new FeeForm();
            fe.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cALENDERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Calender c = new Calender();
            c.Show();
        }

        private void nOTEPADToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Windows\\System32\\notepad.exe");
        }

        private void cALCULATORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Windows\\System32\\calc.exe");
        }

        private void adminFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AdminForm ad = new AdminForm();
            ad.Show();
        }

        private void fEEREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
           // Report.FeeReport FR = new Report.FeeReport();
            //FR.Show();
        }

        private void aDMINISTRATIONREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report.Master RM = new Report.Master();
            RM.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void hELPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help h = new Help();
            h.Show();
        }

        private void rEGISTRATIONREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report.Registration R = new Report.Registration();
            R.Show();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            groupBox1.Left = groupBox1.Left - 8;
            if (groupBox1.Left < 0 - groupBox1.Width)
                groupBox1.Left = panel3.Width;
        }
    }
}
