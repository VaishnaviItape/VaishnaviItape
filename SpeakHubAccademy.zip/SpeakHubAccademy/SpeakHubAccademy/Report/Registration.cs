﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy.Report
{
    public partial class Registration : Form
    {
        Connection con = new Connection();
        public Registration()
        {
            InitializeComponent();
        }

        private void Registration_Load(object sender, EventArgs e)
        {

            
            this.ReportViewer1.RefreshReport();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Close();
                con.cn.Open();
                SqlCommand c = new SqlCommand("Select * from FeeInfo ", con.cn);
                SqlDataAdapter s = new SqlDataAdapter(c);
                s.Fill(con.dt);
                ReportViewer1.LocalReport.DataSources.Clear();
                ReportDataSource Source = new ReportDataSource("DataSet1", con.dt);
                ReportViewer1.LocalReport.ReportPath = (@"D:\CRUD\SpeakHubAccademy\SpeakHubAccademy\Report\Registration.rdlc");
                ReportViewer1.LocalReport.DataSources.Add(Source);
                ReportViewer1.RefreshReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
