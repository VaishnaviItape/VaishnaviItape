﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpeakHubAccademy.Report
{
    public partial class Master : Form
    {
        Connection con = new Connection();
        public Master()
        {
            InitializeComponent();
        }

        private void btnAdministration_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Close();
                con.cn.Open();
                con.da = new SqlDataAdapter("select*from Adminstration ", con.cn);
                con.da.Fill(con.ds, "Adminstration ");
                con.crpt.Load("D:\\CRUD\\SpeakHubAccademy\\SpeakHubAccademy\\Report\\Administration.rpt");
                con.crpt.SetDataSource(con.ds);
                crystalReportViewer2.ReportSource = con.crpt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnRegistration_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Close();
                con.cn.Open();
                con.da = new SqlDataAdapter("select*from Adminstration ", con.cn);
                con.da.Fill(con.ds, "Adminstration ");
                con.crpt.Load("D:\\CRUD\\SpeakHubAccademy\\SpeakHubAccademy\\Report\\Administration.rpt");
                con.crpt.SetDataSource(con.ds);
                crystalReportViewer2.ReportSource = con.crpt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.cn.Close();
                con.cn.Open();
                con.da = new SqlDataAdapter("select*from FeeInfo ", con.cn);
                con.da.Fill(con.ds, "FeeInfo ");
                con.crpt.Load("D:\\CRUD\\SpeakHubAccademy\\SpeakHubAccademy\\Report\\FeeReport.rpt");
                con.crpt.SetDataSource(con.ds);
                crystalReportViewer2.ReportSource = con.crpt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
       
        private void Master_Load(object sender, EventArgs e)
        {
            
        }
    }
}
