﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpeakHubAccademy
{
    class Connection
    {
        public SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\SpeakHubAccademy\SpeakHubAccademy\SpeakHub.mdf;Integrated Security=True");
        public SqlCommand cmd = new SqlCommand();
        public DataTable dt = new DataTable();
        public DataTable dt1 = new DataTable();
        public DataTable dt2 = new DataTable();
        public DataTable dt3 = new DataTable();
        public DataTable dt4 = new DataTable();
        public DataTable dt5 = new DataTable();
        public DataTable dt6 = new DataTable();
        public DataTable dt7 = new DataTable();
        public DataTable dt12 = new DataTable();
        public SqlDataAdapter da = new SqlDataAdapter();
        public SqlDataReader dr;
        public ReportDocument crpt = new ReportDocument();
        public DataSet ds = new DataSet();
    }
}
